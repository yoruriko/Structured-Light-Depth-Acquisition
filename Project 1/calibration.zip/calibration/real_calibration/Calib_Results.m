% Intrinsic and Extrinsic Camera Parameters
%
% This script file can be directly executed under Matlab to recover the camera intrinsic and extrinsic parameters.
% IMPORTANT: This file contains neither the structure of the calibration objects nor the image coordinates of the calibration points.
%            All those complementary variables are saved in the complete matlab data file Calib_Results.mat.
% For more information regarding the calibration model visit http://www.vision.caltech.edu/bouguetj/calib_doc/


%-- Focal length:
fc = [ 21276.082485805556644 ; 360340.895724055008031 ];

%-- Principal point:
cc = [ 2591.500000000000000 ; 1727.500000000000000 ];

%-- Skew coefficient:
alpha_c = 0.000000000000000;

%-- Distortion coefficients:
kc = [ 153.185210352551621 ; -58721.603271694453724 ; 0.007176812728476 ; -1.471971850693168 ; 0.000000000000000 ];

%-- Focal length uncertainty:
fc_error = [ 15026.350191198658649 ; 43173766.605713441967964 ];

%-- Principal point uncertainty:
cc_error = [ 0.000000000000000 ; 0.000000000000000 ];

%-- Skew coefficient uncertainty:
alpha_c_error = 0.000000000000000;

%-- Distortion coefficients uncertainty:
kc_error = [ 287.021446119021675 ; 180795.674883116182173 ; 0.865992242679984 ; 2.210762863927402 ; 0.000000000000000 ];

%-- Image size:
nx = 5184;
ny = 3456;


%-- Various other variables (may be ignored if you do not use the Matlab Calibration Toolbox):
%-- Those variables are used to control which intrinsic parameters should be optimized

n_ima = 3;						% Number of calibration images
est_fc = [ 1 ; 1 ];					% Estimation indicator of the two focal variables
est_aspect_ratio = 1;				% Estimation indicator of the aspect ratio fc(2)/fc(1)
center_optim = 0;					% Estimation indicator of the principal point
est_alpha = 0;						% Estimation indicator of the skew coefficient
est_dist = [ 1 ; 1 ; 1 ; 1 ; 0 ];	% Estimation indicator of the distortion coefficients


%-- Extrinsic parameters:
%-- The rotation (omc_kk) and the translation (Tc_kk) vectors for every calibration image and their uncertainties

%-- Image #1:
omc_1 = [ 1.161477e+00 ; 1.402996e+00 ; -1.323273e+00 ];
Tc_1  = [ 7.935210e+01 ; -2.634409e+00 ; 5.393579e+03 ];
omc_error_1 = [ 6.217492e+00 ; 6.041324e+00 ; 3.618673e+00 ];
Tc_error_1  = [ 3.522909e+00 ; 3.163233e+02 ; 3.633997e+03 ];

%-- Image #2:
omc_2 = [ 1.171610e+00 ; 1.388133e+00 ; -1.307934e+00 ];
Tc_2  = [ 4.368129e+01 ; -2.678368e+00 ; 5.426844e+03 ];
omc_error_2 = [ 6.118510e+00 ; 6.027172e+00 ; 3.689738e+00 ];
Tc_error_2  = [ 2.342377e+00 ; 3.216147e+02 ; 3.679747e+03 ];

%-- Image #3:
omc_3 = [ 1.178088e+00 ; 1.371706e+00 ; -1.296620e+00 ];
Tc_3  = [ 3.975177e+01 ; -2.526980e+00 ; 5.062017e+03 ];
omc_error_3 = [ 5.743969e+00 ; 5.630385e+00 ; 3.461569e+00 ];
Tc_error_3  = [ 2.187631e+00 ; 3.034405e+02 ; 3.433123e+03 ];

